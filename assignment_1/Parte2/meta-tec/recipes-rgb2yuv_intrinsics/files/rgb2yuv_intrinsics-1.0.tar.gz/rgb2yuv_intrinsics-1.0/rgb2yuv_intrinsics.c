#include <stdio.h>

int main(int argc, char *argv[])
{
  printf("Hello from rgb2yuv_intrinsics Yocto World...\n");
  return 0;
}





